#include "uart_tx_state_machine.hpp"

#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>

class FakeWriter final : public gimbal::IUartWriter {
public:
    explicit FakeWriter(std::vector<int> actions) : actions_(std::move(actions)) {}

    gimbal::WriteResult writeSome(const std::uint8_t* data, std::size_t length) noexcept override {
        const int action = action_index_ < actions_.size() ? actions_[action_index_++]
                                                           : static_cast<int>(length);
        if (action < 0) return {gimbal::WriteStatus::error, 0U};
        if (action == 0) return {gimbal::WriteStatus::would_block, 0U};
        const std::size_t count = std::min<std::size_t>(static_cast<std::size_t>(action), length);
        bytes.insert(bytes.end(), data, data + count);
        return {gimbal::WriteStatus::progress, count};
    }

    gimbal::WaitStatus waitWritable(int) noexcept override { return gimbal::WaitStatus::timeout; }
    void discardOutput() noexcept override { ++discard_count; resync_offset = bytes.size(); }

    std::vector<std::uint8_t> bytes;
    std::size_t discard_count{0U};
    std::size_t resync_offset{0U};

private:
    std::vector<int> actions_;
    std::size_t action_index_{0U};
};

int main() {
    using Clock = gimbal::UartTxStateMachine::Clock;
    const auto start = Clock::time_point{} + std::chrono::seconds(1);

    FakeWriter full_writer({10});
    gimbal::UartTxStateMachine full(std::chrono::milliseconds(5), 1);
    full.setLatest({0U, gimbal::CommandMode::rate_control, 1.0F, -2.0F}, start);
    if (full.process(start, full_writer) != gimbal::TxEvent::frame_complete ||
        full_writer.bytes.size() != gimbal::kPacketLength) {
        std::cerr << "UART 完整写测试失败\n";
        return 1;
    }

    FakeWriter partial_writer({1, 9});
    gimbal::UartTxStateMachine partial(std::chrono::milliseconds(5), 1);
    partial.setLatest({0U, gimbal::CommandMode::rate_control, 3.0F, 4.0F}, start);
    if (partial.process(start, partial_writer) != gimbal::TxEvent::frame_complete ||
        partial_writer.bytes.size() != gimbal::kPacketLength ||
        partial.firstWriteAt() != start) {
        std::cerr << "UART 1+9 部分写测试失败\n";
        return 1;
    }

    FakeWriter blocked_writer({1, 0, 0, 0, 10, 10});
    gimbal::UartTxStateMachine blocked(std::chrono::milliseconds(4), 1);
    blocked.setLatest({0U, gimbal::CommandMode::rate_control, 12.0F, -7.0F}, start);
    if (blocked.process(start, blocked_writer) != gimbal::TxEvent::would_block) {
        std::cerr << "UART 多次 EAGAIN 测试失败\n";
        return 1;
    }
    if (blocked.process(start + std::chrono::milliseconds(2), blocked_writer) !=
            gimbal::TxEvent::would_block) {
        std::cerr << "UART 连续 EAGAIN 状态保持失败\n";
        return 1;
    }
    if (blocked.process(start + std::chrono::milliseconds(5), blocked_writer) !=
            gimbal::TxEvent::deadline_timeout ||
        !blocked.communicationFault() || blocked_writer.discard_count != 1U) {
        std::cerr << "UART 帧截止超时测试失败\n";
        return 1;
    }
    blocked.setLatest({0U, gimbal::CommandMode::rate_control, 99.0F, 99.0F},
                      start + std::chrono::milliseconds(6));
    if (blocked.process(start + std::chrono::milliseconds(6), blocked_writer) !=
            gimbal::TxEvent::stop_recovered) {
        std::cerr << "UART 恢复 STOP 帧发送失败\n";
        return 1;
    }
    if (blocked_writer.bytes.size() < blocked_writer.resync_offset + gimbal::kPacketLength) {
        return 1;
    }
    const auto* recovered = blocked_writer.bytes.data() + blocked_writer.resync_offset;
    if (recovered[3] != static_cast<std::uint8_t>(gimbal::CommandMode::stop) ||
        recovered[4] != 0U || recovered[5] != 0U || recovered[6] != 0U || recovered[7] != 0U) {
        std::cerr << "UART 恢复后首先发送的不是零速度 STOP\n";
        return 1;
    }
    return 0;
}
