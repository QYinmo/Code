#include "pid_controller.hpp"

#include <cmath>
#include <iostream>

int main() {
    if (std::fabs(gimbal::AnglePidController::wrapErrorDeg(358.0F) + 2.0F) > 1.0e-5F ||
        std::fabs(gimbal::AnglePidController::wrapErrorDeg(-358.0F) - 2.0F) > 1.0e-5F) {
        std::cerr << "yaw 跨越 ±180° 误差计算失败\n";
        return 1;
    }
    gimbal::PidConfig config{100.0F, 0.0F, 0.0F, 5.0F, 0.1F, 0.0F, 10000.0F};
    gimbal::AnglePidController controller(config);
    float output = 0.0F;
    for (int i = 0; i < 100; ++i) output = controller.update(90.0F, 0.0F, 0.01, false);
    if (!std::isfinite(output) || std::fabs(output) > 5.0001F) {
        std::cerr << "PID 输出限幅失败\n";
        return 1;
    }
    gimbal::PidConfig integral_config{0.0F, 1.0F, 0.0F, 100.0F, 0.1F, 0.0F, 10000.0F};
    gimbal::AnglePidController integral_controller(integral_config);
    for (int i = 0; i < 100; ++i) {
        (void)integral_controller.update(1.0F, 0.0F, 0.01, false);
    }
    if (std::fabs(integral_controller.integralState() - 0.1F) > 1.0e-4F) {
        std::cerr << "PID 积分限幅失败\n";
        return 1;
    }
    controller.reset();
    const float wrapped = controller.update(-179.0F, 179.0F, 0.01, true);
    if (!std::isfinite(wrapped) || std::fabs(wrapped) > 5.0001F) {
        std::cerr << "PID yaw 跨越处理或限幅失败\n";
        return 1;
    }
    return 0;
}
