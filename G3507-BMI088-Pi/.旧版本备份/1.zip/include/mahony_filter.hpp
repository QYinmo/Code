#pragma once

#include "imu_types.hpp"

namespace gimbal {

class MahonyFilter {
public:
    MahonyFilter(float kp, float ki) : kp_(kp), ki_(ki) {}
    bool update(const Vector3& accel_g, const Vector3& gyro_dps, double dt_s, Attitude& attitude) noexcept;
    // 为 GM6020 编码器或视觉提供渐进式相对 yaw 修正，不引入具体依赖。
    void applyYawCorrectionDeg(float reference_yaw_deg, float gain) noexcept;
    void reset() noexcept;

private:
    float kp_;
    float ki_;
    float q0_{1.0F};
    float q1_{0.0F};
    float q2_{0.0F};
    float q3_{0.0F};
    Vector3 integral_{};
    float previous_wrapped_yaw_deg_{0.0F};
    float continuous_yaw_deg_{0.0F};
    bool yaw_initialized_{false};
};

} // namespace gimbal
