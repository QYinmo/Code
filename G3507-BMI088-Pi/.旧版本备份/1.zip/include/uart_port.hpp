#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace gimbal {

class UartPort {
public:
    UartPort() = default;
    ~UartPort();
    UartPort(const UartPort&) = delete;
    UartPort& operator=(const UartPort&) = delete;

    bool openPort(const std::string& device, std::uint32_t baud);
    // 非阻塞写：成功写入的字节数；EAGAIN 返回 0；其他错误返回 -1。
    std::ptrdiff_t writeSome(const std::uint8_t* data, std::size_t length) noexcept;
    void close() noexcept;
    [[nodiscard]] bool isOpen() const noexcept { return fd_ >= 0; }
    [[nodiscard]] const std::string& lastError() const noexcept { return last_error_; }

private:
    int fd_{-1};
    std::string last_error_;
};

} // namespace gimbal
