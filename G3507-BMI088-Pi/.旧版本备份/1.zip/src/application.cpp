#include "application.hpp"

#include "low_pass_filter.hpp"
#include "mahony_filter.hpp"
#include "pid_controller.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <poll.h>
#include <sstream>
#include <thread>
#include <unistd.h>
#include <utility>

namespace gimbal {
namespace {

using Clock = std::chrono::steady_clock;

Clock::duration periodFromFrequency(double frequency_hz) {
    return std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(1.0 / frequency_hz));
}

void updateMaximum(std::atomic<std::int64_t>& maximum, std::int64_t value) {
    auto current = maximum.load(std::memory_order_relaxed);
    while (value > current &&
           !maximum.compare_exchange_weak(current, value, std::memory_order_relaxed)) {}
}

} // namespace

Application::Application(AppConfig config, RunOptions options)
    : config_(std::move(config)), options_(options), axis_mapping_(config_.axis_mapping) {
    target_yaw_deg_.store(options_.target_override ? options_.target_yaw_deg
                                                    : config_.default_target_yaw_deg);
    target_pitch_deg_.store(options_.target_override ? options_.target_pitch_deg
                                                      : config_.default_target_pitch_deg);
    shared_command_.updated = Clock::now();
}

Application::~Application() {
    requestStop();
    if (control_thread_.joinable()) control_thread_.join();
    if (uart_thread_.joinable()) uart_thread_.join();
    if (status_thread_.joinable()) status_thread_.join();
    if (input_thread_.joinable()) input_thread_.join();
}

void Application::setTargetAngles(float yaw_deg, float pitch_deg) noexcept {
    if (std::isfinite(yaw_deg) && std::isfinite(pitch_deg)) {
        target_yaw_deg_.store(yaw_deg);
        target_pitch_deg_.store(pitch_deg);
    }
}

void Application::publishCommand(float yaw_rate_dps, float pitch_rate_dps, CommandMode mode) {
    if (!std::isfinite(yaw_rate_dps) || !std::isfinite(pitch_rate_dps)) {
        yaw_rate_dps = 0.0F;
        pitch_rate_dps = 0.0F;
        mode = CommandMode::fault;
    }
    std::lock_guard<std::mutex> lock(command_mutex_);
    shared_command_.yaw_rate_dps = yaw_rate_dps;
    shared_command_.pitch_rate_dps = pitch_rate_dps;
    shared_command_.mode = mode;
    shared_command_.updated = Clock::now();
}

Application::SharedCommand Application::commandSnapshot() {
    std::lock_guard<std::mutex> lock(command_mutex_);
    return shared_command_;
}

bool Application::calibrate(Bmi088& imu, CalibrationResult& result) {
    const auto period = periodFromFrequency(config_.imu_frequency_hz);
    const std::size_t required_samples = std::max<std::size_t>(
        10U, static_cast<std::size_t>(config_.calibration_seconds * config_.imu_frequency_hz));
    for (int attempt = 1; attempt <= 3 && !stop_requested_.load(); ++attempt) {
        std::cout << "开始第 " << attempt << " 次静止校准（约 " << config_.calibration_seconds
                  << " 秒），请勿移动云台……" << std::endl;
        publishCommand(0.0F, 0.0F, CommandMode::stop);
        Vector3 gyro_mean{};
        Vector3 gyro_m2{};
        Vector3 accel_mean{};
        Vector3 accel_m2{};
        std::size_t count = 0U;
        auto next = Clock::now();
        bool read_failed = false;
        while (count < required_samples && !stop_requested_.load()) {
            next += period;
            ImuSample sample{};
            if (!imu.readSample(sample)) {
                ++imu_failures_;
                if (imu.consecutiveFailures() >= config_.max_consecutive_spi_failures) {
                    std::cerr << "校准期间 SPI 连续读取失败：" << imu.lastError() << std::endl;
                    read_failed = true;
                    break;
                }
                std::this_thread::sleep_until(next);
                continue;
            }
            const Vector3 accel = axis_mapping_.apply({sample.ax, sample.ay, sample.az});
            const Vector3 gyro = axis_mapping_.apply({sample.gx, sample.gy, sample.gz});
            ++count;
            const float n = static_cast<float>(count);
            const Vector3 delta{gyro.x - gyro_mean.x, gyro.y - gyro_mean.y, gyro.z - gyro_mean.z};
            gyro_mean.x += delta.x / n;
            gyro_mean.y += delta.y / n;
            gyro_mean.z += delta.z / n;
            gyro_m2.x += delta.x * (gyro.x - gyro_mean.x);
            gyro_m2.y += delta.y * (gyro.y - gyro_mean.y);
            gyro_m2.z += delta.z * (gyro.z - gyro_mean.z);
            const Vector3 accel_delta{accel.x - accel_mean.x, accel.y - accel_mean.y,
                                      accel.z - accel_mean.z};
            accel_mean.x += accel_delta.x / n;
            accel_mean.y += accel_delta.y / n;
            accel_mean.z += accel_delta.z / n;
            accel_m2.x += accel_delta.x * (accel.x - accel_mean.x);
            accel_m2.y += accel_delta.y * (accel.y - accel_mean.y);
            accel_m2.z += accel_delta.z * (accel.z - accel_mean.z);
            std::this_thread::sleep_until(next);
        }
        if (stop_requested_.load()) return false;
        if (read_failed || count < 2U) return false;
        const float divisor = static_cast<float>(count - 1U);
        const Vector3 stddev{std::sqrt(gyro_m2.x / divisor), std::sqrt(gyro_m2.y / divisor),
                             std::sqrt(gyro_m2.z / divisor)};
        const Vector3 accel_stddev{std::sqrt(accel_m2.x / divisor), std::sqrt(accel_m2.y / divisor),
                                   std::sqrt(accel_m2.z / divisor)};
        const float mean_rate = std::sqrt(gyro_mean.x * gyro_mean.x + gyro_mean.y * gyro_mean.y +
                                          gyro_mean.z * gyro_mean.z);
        const float maximum_stddev = std::max({stddev.x, stddev.y, stddev.z});
        const float maximum_accel_stddev = std::max({accel_stddev.x, accel_stddev.y, accel_stddev.z});
        const float accel_norm = std::sqrt(accel_mean.x * accel_mean.x + accel_mean.y * accel_mean.y +
                                           accel_mean.z * accel_mean.z);
        if (maximum_stddev > config_.calibration_max_gyro_stddev_dps ||
            mean_rate > config_.calibration_max_mean_rate_dps ||
            maximum_accel_stddev > config_.calibration_max_accel_stddev_g ||
            accel_norm < 0.8F || accel_norm > 1.2F) {
            std::cerr << "检测到云台运动：陀螺仪最大标准差 " << maximum_stddev
                      << " °/s，均值模长 " << mean_rate << " °/s，加速度最大标准差 "
                      << maximum_accel_stddev << " g，均值模长 " << accel_norm
                      << " g；请保持静止，准备重试。"
                      << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        result.gyro_bias_dps = gyro_mean;
        result.accel_mean_g = accel_mean;
        result.valid = true;
        std::cout << "校准完成：陀螺仪零偏 [" << gyro_mean.x << ", " << gyro_mean.y << ", "
                  << gyro_mean.z << "] °/s；加速度均值 [" << result.accel_mean_g.x << ", "
                  << result.accel_mean_g.y << ", " << result.accel_mean_g.z << "] g" << std::endl;
        return true;
    }
    std::cerr << "三次校准均检测到明显运动，程序保持停止状态。" << std::endl;
    return false;
}

bool Application::saveCalibration(const CalibrationResult& result) const {
    if (!config_.save_calibration) return true;
    std::ofstream file(config_.calibration_output_file, std::ios::trunc);
    if (!file) {
        std::cerr << "无法保存校准结果到 " << config_.calibration_output_file << std::endl;
        return false;
    }
    file << "# BMI088 启动静止校准结果，仅供记录和后续集成使用\n"
         << "gyro_bias_dps = " << result.gyro_bias_dps.x << ',' << result.gyro_bias_dps.y << ','
         << result.gyro_bias_dps.z << "\naccel_mean_g = " << result.accel_mean_g.x << ','
         << result.accel_mean_g.y << ',' << result.accel_mean_g.z << '\n';
    if (!file) {
        std::cerr << "写入校准结果失败：" << config_.calibration_output_file << std::endl;
        return false;
    }
    std::cout << "校准结果已保存到 " << config_.calibration_output_file << std::endl;
    return true;
}

void Application::controlLoop(Bmi088& imu, const CalibrationResult& calibration) {
    LowPassFilter accel_filters[3]{LowPassFilter(config_.accel_cutoff_hz),
                                   LowPassFilter(config_.accel_cutoff_hz),
                                   LowPassFilter(config_.accel_cutoff_hz)};
    LowPassFilter gyro_filters[3]{LowPassFilter(config_.gyro_cutoff_hz),
                                  LowPassFilter(config_.gyro_cutoff_hz),
                                  LowPassFilter(config_.gyro_cutoff_hz)};
    MahonyFilter attitude_filter(config_.mahony_kp, config_.mahony_ki);
    AnglePidController yaw_controller(config_.yaw_pid);
    AnglePidController pitch_controller(config_.pitch_pid);
    const auto period = periodFromFrequency(config_.imu_frequency_hz);
    const auto timeout = period * 5;
    auto next = Clock::now();
    double previous_timestamp_s = 0.0;
    bool was_enabled = false;

    while (!stop_requested_.load()) {
        const auto cycle_start = Clock::now();
        if (cycle_start > next) {
            const auto late = std::chrono::duration_cast<std::chrono::microseconds>(cycle_start - next).count();
            updateMaximum(max_imu_lateness_us_, late);
        }
        next += period;
        ImuSample sample{};
        if (!imu.readSample(sample)) {
            ++imu_failures_;
            publishCommand(0.0F, 0.0F, CommandMode::fault);
            if (imu.consecutiveFailures() == config_.max_consecutive_spi_failures) {
                std::cerr << "SPI 连续读取失败达到安全阈值：" << imu.lastError() << std::endl;
            }
            std::this_thread::sleep_until(next);
            continue;
        }
        double dt_s = previous_timestamp_s > 0.0 ? sample.timestamp_s - previous_timestamp_s
                                                  : 1.0 / config_.imu_frequency_hz;
        previous_timestamp_s = sample.timestamp_s;
        if (!std::isfinite(dt_s) || dt_s <= 0.0 || dt_s > 5.0 / config_.imu_frequency_hz) {
            ++imu_failures_;
            attitude_filter.reset();
            for (auto& filter : accel_filters) filter.reset();
            for (auto& filter : gyro_filters) filter.reset();
            yaw_controller.reset();
            pitch_controller.reset();
            publishCommand(0.0F, 0.0F, CommandMode::fault);
            std::this_thread::sleep_until(next);
            continue;
        }
        const Vector3 mapped_accel = axis_mapping_.apply({sample.ax, sample.ay, sample.az});
        Vector3 mapped_gyro = axis_mapping_.apply({sample.gx, sample.gy, sample.gz});
        mapped_gyro.x -= calibration.gyro_bias_dps.x;
        mapped_gyro.y -= calibration.gyro_bias_dps.y;
        mapped_gyro.z -= calibration.gyro_bias_dps.z;
        const Vector3 filtered_accel{accel_filters[0].update(mapped_accel.x, dt_s),
                                     accel_filters[1].update(mapped_accel.y, dt_s),
                                     accel_filters[2].update(mapped_accel.z, dt_s)};
        const Vector3 filtered_gyro{gyro_filters[0].update(mapped_gyro.x, dt_s),
                                    gyro_filters[1].update(mapped_gyro.y, dt_s),
                                    gyro_filters[2].update(mapped_gyro.z, dt_s)};
        Attitude current{};
        current.timestamp_s = sample.timestamp_s;
        if (!attitude_filter.update(filtered_accel, filtered_gyro, dt_s, current)) {
            ++imu_failures_;
            publishCommand(0.0F, 0.0F, CommandMode::fault);
            std::this_thread::sleep_until(next);
            continue;
        }
        {
            std::lock_guard<std::mutex> lock(attitude_mutex_);
            attitude_ = current;
        }
        ++imu_iterations_;

        const bool enabled = control_enabled_.load() && !options_.imu_only;
        if (enabled != was_enabled) {
            yaw_controller.reset(current.yaw_deg);
            pitch_controller.reset(current.pitch_deg);
            was_enabled = enabled;
        }
        if (enabled && Clock::now() - cycle_start <= timeout) {
            const float yaw_rate = yaw_controller.update(target_yaw_deg_.load(), current.yaw_deg, dt_s, true);
            const float pitch_rate = pitch_controller.update(target_pitch_deg_.load(), current.pitch_deg, dt_s, false);
            publishCommand(yaw_rate, pitch_rate, CommandMode::rate_control);
        } else {
            publishCommand(0.0F, 0.0F, enabled ? CommandMode::fault : CommandMode::stop);
        }
        std::this_thread::sleep_until(next);
        // 极端过载时重新锚定，避免无意义地连续追赶数百个过期周期。
        if (Clock::now() - next > timeout) next = Clock::now();
    }
    publishCommand(0.0F, 0.0F, CommandMode::stop);
}

void Application::uartLoop() {
    const auto period = periodFromFrequency(config_.uart_frequency_hz);
    auto next = Clock::now();
    std::array<std::uint8_t, kPacketLength> pending{};
    std::size_t pending_offset = kPacketLength;
    std::uint8_t sequence = 0U;
    while (!stop_requested_.load()) {
        const auto now = Clock::now();
        if (now > next) {
            updateMaximum(max_uart_lateness_us_,
                std::chrono::duration_cast<std::chrono::microseconds>(now - next).count());
        }
        next += period;
        // 已发生部分写入的帧必须先完成；尚未写入的旧帧可直接被最新目标替换。
        if (pending_offset >= kPacketLength) {
            SharedCommand latest = commandSnapshot();
            if (now - latest.updated > std::chrono::duration<double>(config_.command_timeout_s)) {
                latest = {};
                latest.mode = CommandMode::stop;
            }
            if (latest.mode != CommandMode::rate_control) {
                latest.yaw_rate_dps = 0.0F;
                latest.pitch_rate_dps = 0.0F;
            }
            pending = serializeCommand({sequence++, latest.mode,
                                        latest.yaw_rate_dps, latest.pitch_rate_dps});
            pending_offset = 0U;
        }
        if (options_.dry_run) {
            pending_offset = kPacketLength;
            ++uart_packets_;
        } else if (uart_.isOpen()) {
            const auto written = uart_.writeSome(pending.data() + pending_offset,
                                                 kPacketLength - pending_offset);
            if (written > 0) {
                pending_offset += static_cast<std::size_t>(written);
                if (pending_offset == kPacketLength) ++uart_packets_;
            } else if (written < 0) {
                ++uart_failures_;
                pending_offset = kPacketLength;
            } else {
                ++uart_failures_;
            }
        }
        std::this_thread::sleep_until(next);
        if (Clock::now() - next > period * 5) next = Clock::now();
    }
}

void Application::statusLoop() {
    const auto interval = std::chrono::duration<double>(1.0 / config_.log_frequency_hz);
    std::uint64_t last_imu = 0U;
    std::uint64_t last_uart = 0U;
    while (!stop_requested_.load()) {
        std::this_thread::sleep_for(interval);
        if (stop_requested_.load()) break;
        const auto imu_count = imu_iterations_.load();
        const auto uart_count = uart_packets_.load();
        Attitude current{};
        {
            std::lock_guard<std::mutex> lock(attitude_mutex_);
            current = attitude_;
        }
        std::cout << "状态：IMU " << (imu_count - last_imu) * config_.log_frequency_hz
                  << " Hz，UART " << (uart_count - last_uart) * config_.log_frequency_hz
                  << " Hz，姿态 [yaw=" << current.yaw_deg << "°, pitch=" << current.pitch_deg
                  << "°, roll=" << current.roll_deg << "°]，累计失败 [SPI="
                  << imu_failures_.load() << ", UART=" << uart_failures_.load()
                  << "]，最大延迟 [IMU=" << max_imu_lateness_us_.exchange(0)
                  << " us, UART=" << max_uart_lateness_us_.exchange(0) << " us]" << std::endl;
        last_imu = imu_count;
        last_uart = uart_count;
    }
}

void Application::inputLoop() {
    std::cout << "终端命令：target <yaw_deg> <pitch_deg>、run、stop、status、quit" << std::endl;
    while (!stop_requested_.load()) {
        pollfd descriptor{STDIN_FILENO, POLLIN, 0};
        const int result = ::poll(&descriptor, 1U, 200);
        if (result < 0) continue;
        if (result == 0) continue;
        if ((descriptor.revents & (POLLHUP | POLLERR | POLLNVAL)) != 0) return;
        if ((descriptor.revents & POLLIN) == 0) continue;
        std::string line;
        if (!std::getline(std::cin, line)) return;
        std::istringstream command(line);
        std::string name;
        command >> name;
        if (name == "target") {
            float yaw = 0.0F;
            float pitch = 0.0F;
            if (command >> yaw >> pitch && std::isfinite(yaw) && std::isfinite(pitch)) {
                setTargetAngles(yaw, pitch);
                std::cout << "目标已更新为 yaw=" << yaw << "°，pitch=" << pitch << "°" << std::endl;
            } else {
                std::cerr << "用法：target <yaw_deg> <pitch_deg>" << std::endl;
            }
        } else if (name == "run") {
            control_enabled_.store(true);
            std::cout << "角度外环已启用。" << std::endl;
        } else if (name == "stop") {
            control_enabled_.store(false);
            publishCommand(0.0F, 0.0F, CommandMode::stop);
            std::cout << "已切换到停止模式。" << std::endl;
        } else if (name == "status") {
            const SharedCommand current = commandSnapshot();
            std::cout << "当前目标 yaw=" << target_yaw_deg_.load() << "°，pitch="
                      << target_pitch_deg_.load() << "°；模式="
                      << static_cast<unsigned>(current.mode) << std::endl;
        } else if (name == "quit" || name == "exit") {
            requestStop();
        } else if (!name.empty()) {
            std::cerr << "未知命令：" << name << std::endl;
        }
    }
}

void Application::sendShutdownPackets() {
    if (!uart_.isOpen() || options_.dry_run || options_.imu_only) return;
    std::uint8_t sequence = 0U;
    for (int packet_index = 0; packet_index < 5; ++packet_index) {
        const auto packet = serializeCommand({sequence++, CommandMode::stop, 0.0F, 0.0F});
        std::size_t offset = 0U;
        for (int attempt = 0; offset < packet.size() && attempt < 20; ++attempt) {
            const auto written = uart_.writeSome(packet.data() + offset, packet.size() - offset);
            if (written > 0) offset += static_cast<std::size_t>(written);
            else if (written < 0) break;
            else std::this_thread::sleep_for(std::chrono::microseconds(100));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}

int Application::run() {
    Bmi088 imu({config_.accel_spi_device, config_.gyro_spi_device, config_.spi_speed_hz,
                config_.accel_conf, config_.gyro_bandwidth});

    if (options_.uart_test) {
        const float safety_limit = 20.0F;
        const float yaw_rate = std::clamp(config_.uart_test_yaw_rate_dps, -safety_limit, safety_limit);
        const float pitch_rate = std::clamp(config_.uart_test_pitch_rate_dps, -safety_limit, safety_limit);
        std::cerr << "警告：UART 测试模式不读取 BMI088，将发送固定小角速度 yaw=" << yaw_rate
                  << " °/s、pitch=" << pitch_rate << " °/s；请确保机构安全。" << std::endl;
        if (!options_.dry_run && !uart_.openPort(config_.uart_device, config_.uart_baud)) {
            std::cerr << uart_.lastError() << std::endl;
            return 2;
        }
        publishCommand(yaw_rate, pitch_rate, CommandMode::rate_control);
        uart_thread_ = std::thread(&Application::uartLoop, this);
        status_thread_ = std::thread(&Application::statusLoop, this);
        input_thread_ = std::thread(&Application::inputLoop, this);
        while (!stop_requested_.load()) {
            publishCommand(yaw_rate, pitch_rate, CommandMode::rate_control);
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    } else {
        if (!imu.initialize()) {
            std::cerr << "BMI088 初始化失败：" << imu.lastError()
                      << "。未发送任何有效运动命令。" << std::endl;
            return 2;
        }
        if (!options_.imu_only && !options_.dry_run &&
            !uart_.openPort(config_.uart_device, config_.uart_baud)) {
            std::cerr << uart_.lastError() << "。未发送任何有效运动命令。" << std::endl;
            return 2;
        }
        if (!options_.imu_only) uart_thread_ = std::thread(&Application::uartLoop, this);
        status_thread_ = std::thread(&Application::statusLoop, this);
        input_thread_ = std::thread(&Application::inputLoop, this);
        CalibrationResult calibration{};
        if (!calibrate(imu, calibration)) {
            publishCommand(0.0F, 0.0F, CommandMode::fault);
            requestStop();
        } else {
            (void)saveCalibration(calibration);
            control_enabled_.store(!options_.imu_only);
            control_thread_ = std::thread(&Application::controlLoop, this, std::ref(imu), calibration);
        }
        while (!stop_requested_.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }

    requestStop();
    if (control_thread_.joinable()) control_thread_.join();
    if (uart_thread_.joinable()) uart_thread_.join();
    if (status_thread_.joinable()) status_thread_.join();
    if (input_thread_.joinable()) input_thread_.join();
    sendShutdownPackets();
    uart_.close();
    imu.close();
    std::cout << "程序已安全停止。" << std::endl;
    return fatal_error_.empty() ? 0 : 2;
}

} // namespace gimbal
