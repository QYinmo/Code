#include "mahony_filter.hpp"

#include <algorithm>
#include <cmath>

namespace gimbal {

void MahonyFilter::reset() noexcept {
    q0_ = 1.0F; q1_ = 0.0F; q2_ = 0.0F; q3_ = 0.0F;
    integral_ = {};
    previous_wrapped_yaw_deg_ = 0.0F;
    continuous_yaw_deg_ = 0.0F;
    yaw_initialized_ = false;
}

void MahonyFilter::applyYawCorrectionDeg(float reference_yaw_deg, float gain) noexcept {
    if (!yaw_initialized_ || !std::isfinite(reference_yaw_deg) || !std::isfinite(gain)) return;
    const float limited_gain = std::clamp(gain, 0.0F, 1.0F);
    float error = reference_yaw_deg - continuous_yaw_deg_;
    while (error > 180.0F) error -= 360.0F;
    while (error < -180.0F) error += 360.0F;
    continuous_yaw_deg_ += limited_gain * error;
}

bool MahonyFilter::update(const Vector3& accel_g, const Vector3& gyro_dps,
                          double dt_s, Attitude& attitude) noexcept {
    if (!std::isfinite(dt_s) || dt_s <= 0.0) return false;
    // 异常调度间隔限幅，避免一次卡顿造成四元数突跳。
    const float dt = static_cast<float>(std::clamp(dt_s, 0.0002, 0.02));
    const float accel_norm_sq = accel_g.x * accel_g.x + accel_g.y * accel_g.y + accel_g.z * accel_g.z;
    if (!std::isfinite(accel_norm_sq) || accel_norm_sq < 0.01F || accel_norm_sq > 16.0F) return false;
    const float inv_accel_norm = 1.0F / std::sqrt(accel_norm_sq);
    const float ax = accel_g.x * inv_accel_norm;
    const float ay = accel_g.y * inv_accel_norm;
    const float az = accel_g.z * inv_accel_norm;

    // 估计重力方向与测量方向的叉积误差；无磁力计时无法校正绕重力轴的 yaw。
    const float vx = 2.0F * (q1_ * q3_ - q0_ * q2_);
    const float vy = 2.0F * (q0_ * q1_ + q2_ * q3_);
    const float vz = q0_ * q0_ - q1_ * q1_ - q2_ * q2_ + q3_ * q3_;
    const float ex = ay * vz - az * vy;
    const float ey = az * vx - ax * vz;
    const float ez = ax * vy - ay * vx;
    if (ki_ > 0.0F) {
        integral_.x += ki_ * ex * dt;
        integral_.y += ki_ * ey * dt;
        integral_.z += ki_ * ez * dt;
    } else {
        integral_ = {};
    }

    constexpr float deg_to_rad = 0.01745329251994329577F;
    float gx = gyro_dps.x * deg_to_rad + kp_ * ex + integral_.x;
    float gy = gyro_dps.y * deg_to_rad + kp_ * ey + integral_.y;
    float gz = gyro_dps.z * deg_to_rad + kp_ * ez + integral_.z;
    if (!std::isfinite(gx) || !std::isfinite(gy) || !std::isfinite(gz)) return false;

    const float half_dt = 0.5F * dt;
    const float old_q0 = q0_;
    const float old_q1 = q1_;
    const float old_q2 = q2_;
    const float old_q3 = q3_;
    q0_ += (-old_q1 * gx - old_q2 * gy - old_q3 * gz) * half_dt;
    q1_ += ( old_q0 * gx + old_q2 * gz - old_q3 * gy) * half_dt;
    q2_ += ( old_q0 * gy - old_q1 * gz + old_q3 * gx) * half_dt;
    q3_ += ( old_q0 * gz + old_q1 * gy - old_q2 * gx) * half_dt;
    const float q_norm_sq = q0_ * q0_ + q1_ * q1_ + q2_ * q2_ + q3_ * q3_;
    if (!std::isfinite(q_norm_sq) || q_norm_sq < 1.0e-12F) {
        reset();
        return false;
    }
    const float inv_q_norm = 1.0F / std::sqrt(q_norm_sq);
    q0_ *= inv_q_norm; q1_ *= inv_q_norm; q2_ *= inv_q_norm; q3_ *= inv_q_norm;

    constexpr float rad_to_deg = 57.295779513082320876F;
    const float roll = std::atan2(2.0F * (q0_ * q1_ + q2_ * q3_),
                                  1.0F - 2.0F * (q1_ * q1_ + q2_ * q2_)) * rad_to_deg;
    const float pitch_argument = std::clamp(2.0F * (q0_ * q2_ - q3_ * q1_), -1.0F, 1.0F);
    const float pitch = std::asin(pitch_argument) * rad_to_deg;
    const float wrapped_yaw = std::atan2(2.0F * (q0_ * q3_ + q1_ * q2_),
                                         1.0F - 2.0F * (q2_ * q2_ + q3_ * q3_)) * rad_to_deg;
    if (!yaw_initialized_) {
        continuous_yaw_deg_ = wrapped_yaw;
        yaw_initialized_ = true;
    } else {
        float delta = wrapped_yaw - previous_wrapped_yaw_deg_;
        if (delta > 180.0F) delta -= 360.0F;
        if (delta < -180.0F) delta += 360.0F;
        continuous_yaw_deg_ += delta;
    }
    previous_wrapped_yaw_deg_ = wrapped_yaw;
    attitude.roll_deg = roll;
    attitude.pitch_deg = pitch;
    attitude.yaw_deg = continuous_yaw_deg_;
    attitude.valid = std::isfinite(roll) && std::isfinite(pitch) && std::isfinite(continuous_yaw_deg_);
    return attitude.valid;
}

} // namespace gimbal
