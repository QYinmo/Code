#include "config.hpp"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>

namespace gimbal {
namespace {

std::string trim(std::string value) {
    const auto not_space = [](unsigned char c) { return !std::isspace(c); };
    value.erase(value.begin(), std::find_if(value.begin(), value.end(), not_space));
    value.erase(std::find_if(value.rbegin(), value.rend(), not_space).base(), value.end());
    return value;
}

bool parseFloat(const std::string& text, float& value) {
    try {
        std::size_t used = 0U;
        value = std::stof(text, &used);
        return used == text.size();
    } catch (...) {
        return false;
    }
}

bool parseDouble(const std::string& text, double& value) {
    try {
        std::size_t used = 0U;
        value = std::stod(text, &used);
        return used == text.size();
    } catch (...) {
        return false;
    }
}

bool parseUnsigned(const std::string& text, std::uint32_t& value) {
    try {
        std::size_t used = 0U;
        const auto parsed = std::stoull(text, &used, 0);
        if (used != text.size() || parsed > 0xFFFFFFFFULL) {
            return false;
        }
        value = static_cast<std::uint32_t>(parsed);
        return true;
    } catch (...) {
        return false;
    }
}

bool parseMatrix(const std::string& text, std::array<float, 9>& matrix) {
    std::stringstream stream(text);
    std::string token;
    std::size_t index = 0U;
    while (std::getline(stream, token, ',')) {
        if (index >= matrix.size() || !parseFloat(trim(token), matrix[index])) {
            return false;
        }
        ++index;
    }
    return index == matrix.size();
}

bool parseBool(const std::string& text, bool& value) {
    std::string normalized = text;
    std::transform(normalized.begin(), normalized.end(), normalized.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (normalized == "true" || normalized == "1" || normalized == "yes") {
        value = true;
        return true;
    }
    if (normalized == "false" || normalized == "0" || normalized == "no") {
        value = false;
        return true;
    }
    return false;
}

} // namespace

bool loadConfig(const std::string& path, AppConfig& config, std::string& error) {
    std::ifstream file(path);
    if (!file) {
        error = "无法打开配置文件：" + path;
        return false;
    }

    std::unordered_map<std::string, std::string> entries;
    std::string line;
    std::size_t line_number = 0U;
    while (std::getline(file, line)) {
        ++line_number;
        const auto comment = line.find('#');
        if (comment != std::string::npos) {
            line.erase(comment);
        }
        line = trim(line);
        if (line.empty()) {
            continue;
        }
        const auto separator = line.find('=');
        if (separator == std::string::npos) {
            error = "配置文件第 " + std::to_string(line_number) + " 行缺少 '='";
            return false;
        }
        const std::string key = trim(line.substr(0U, separator));
        const std::string value = trim(line.substr(separator + 1U));
        if (key.empty() || value.empty()) {
            error = "配置文件第 " + std::to_string(line_number) + " 行键或值为空";
            return false;
        }
        entries[key] = value;
    }

    const auto set_string = [&entries](const char* key, std::string& output) {
        const auto it = entries.find(key);
        if (it != entries.end()) {
            output = it->second;
        }
    };
    const auto set_float = [&entries, &error](const char* key, float& output) {
        const auto it = entries.find(key);
        if (it == entries.end()) return true;
        if (!parseFloat(it->second, output)) {
            error = std::string("配置项不是有效浮点数：") + key;
            return false;
        }
        return true;
    };
    const auto set_double = [&entries, &error](const char* key, double& output) {
        const auto it = entries.find(key);
        if (it == entries.end()) return true;
        if (!parseDouble(it->second, output)) {
            error = std::string("配置项不是有效浮点数：") + key;
            return false;
        }
        return true;
    };
    const auto set_u32 = [&entries, &error](const char* key, std::uint32_t& output) {
        const auto it = entries.find(key);
        if (it == entries.end()) return true;
        if (!parseUnsigned(it->second, output)) {
            error = std::string("配置项不是有效无符号整数：") + key;
            return false;
        }
        return true;
    };
    const auto set_bool = [&entries, &error](const char* key, bool& output) {
        const auto it = entries.find(key);
        if (it == entries.end()) return true;
        if (!parseBool(it->second, output)) {
            error = std::string("配置项不是有效布尔值：") + key;
            return false;
        }
        return true;
    };

    set_string("accel_spi_device", config.accel_spi_device);
    set_string("gyro_spi_device", config.gyro_spi_device);
    set_string("uart_device", config.uart_device);
    set_string("calibration_output_file", config.calibration_output_file);
    if (!set_u32("spi_speed_hz", config.spi_speed_hz) ||
        !set_u32("uart_baud", config.uart_baud) ||
        !set_double("imu_frequency_hz", config.imu_frequency_hz) ||
        !set_double("uart_frequency_hz", config.uart_frequency_hz) ||
        !set_float("accel_cutoff_hz", config.accel_cutoff_hz) ||
        !set_float("gyro_cutoff_hz", config.gyro_cutoff_hz) ||
        !set_float("mahony_kp", config.mahony_kp) ||
        !set_float("mahony_ki", config.mahony_ki) ||
        !set_float("yaw_kp", config.yaw_pid.kp) ||
        !set_float("yaw_ki", config.yaw_pid.ki) ||
        !set_float("yaw_kd", config.yaw_pid.kd) ||
        !set_float("yaw_max_rate_dps", config.yaw_pid.output_limit_dps) ||
        !set_float("yaw_integral_limit", config.yaw_pid.integral_limit) ||
        !set_float("yaw_deadband_deg", config.yaw_pid.deadband_deg) ||
        !set_float("yaw_target_slew_dps", config.yaw_pid.target_slew_dps) ||
        !set_float("pitch_kp", config.pitch_pid.kp) ||
        !set_float("pitch_ki", config.pitch_pid.ki) ||
        !set_float("pitch_kd", config.pitch_pid.kd) ||
        !set_float("pitch_max_rate_dps", config.pitch_pid.output_limit_dps) ||
        !set_float("pitch_integral_limit", config.pitch_pid.integral_limit) ||
        !set_float("pitch_deadband_deg", config.pitch_pid.deadband_deg) ||
        !set_float("pitch_target_slew_dps", config.pitch_pid.target_slew_dps) ||
        !set_float("default_target_yaw_deg", config.default_target_yaw_deg) ||
        !set_float("default_target_pitch_deg", config.default_target_pitch_deg) ||
        !set_double("calibration_seconds", config.calibration_seconds) ||
        !set_float("calibration_max_gyro_stddev_dps", config.calibration_max_gyro_stddev_dps) ||
        !set_float("calibration_max_mean_rate_dps", config.calibration_max_mean_rate_dps) ||
        !set_float("calibration_max_accel_stddev_g", config.calibration_max_accel_stddev_g) ||
        !set_bool("save_calibration", config.save_calibration) ||
        !set_double("log_frequency_hz", config.log_frequency_hz) ||
        !set_u32("max_consecutive_spi_failures", config.max_consecutive_spi_failures) ||
        !set_double("command_timeout_s", config.command_timeout_s) ||
        !set_float("uart_test_yaw_rate_dps", config.uart_test_yaw_rate_dps) ||
        !set_float("uart_test_pitch_rate_dps", config.uart_test_pitch_rate_dps)) {
        return false;
    }

    std::uint32_t temporary = config.accel_conf;
    if (!set_u32("accel_conf", temporary) || temporary > 0xFFU) {
        error = "accel_conf 必须在 0x00 到 0xFF 之间";
        return false;
    }
    config.accel_conf = static_cast<std::uint8_t>(temporary);
    temporary = config.gyro_bandwidth;
    if (!set_u32("gyro_bandwidth", temporary) || temporary > 0x07U) {
        error = "gyro_bandwidth 必须在 0x00 到 0x07 之间";
        return false;
    }
    config.gyro_bandwidth = static_cast<std::uint8_t>(temporary);

    const auto matrix_it = entries.find("axis_mapping");
    if (matrix_it != entries.end() && !parseMatrix(matrix_it->second, config.axis_mapping)) {
        error = "axis_mapping 必须包含 9 个逗号分隔的数字";
        return false;
    }
    return validateConfig(config, error);
}

bool validateConfig(const AppConfig& config, std::string& error) {
    if (config.accel_spi_device.empty() || config.gyro_spi_device.empty() || config.uart_device.empty() ||
        (config.save_calibration && config.calibration_output_file.empty())) {
        error = "设备路径不能为空";
        return false;
    }
    if (config.spi_speed_hz == 0U || config.imu_frequency_hz < 1.0 ||
        config.uart_frequency_hz < 1.0 || config.log_frequency_hz <= 0.0) {
        error = "SPI 速度和各线程频率必须为正数";
        return false;
    }
    if (config.calibration_seconds < 0.1 || config.command_timeout_s <= 0.0 ||
        config.calibration_max_accel_stddev_g <= 0.0F ||
        config.max_consecutive_spi_failures == 0U) {
        error = "校准时间、命令超时和 SPI 失败阈值必须为正数";
        return false;
    }
    if (config.accel_cutoff_hz <= 0.0F || config.gyro_cutoff_hz <= 0.0F ||
        config.mahony_kp < 0.0F || config.mahony_ki < 0.0F) {
        error = "滤波截止频率必须为正，Mahony 增益不能为负";
        return false;
    }
    const auto valid_pid = [](const PidConfig& pid) {
        return pid.output_limit_dps > 0.0F && pid.integral_limit >= 0.0F &&
               pid.deadband_deg >= 0.0F && pid.target_slew_dps > 0.0F;
    };
    if (!valid_pid(config.yaw_pid) || !valid_pid(config.pitch_pid)) {
        error = "PID 限幅、死区或目标斜坡参数无效";
        return false;
    }
    if (!AxisMapping(config.axis_mapping).valid()) {
        error = "axis_mapping 不是正交单位矩阵";
        return false;
    }
    return true;
}

} // namespace gimbal
