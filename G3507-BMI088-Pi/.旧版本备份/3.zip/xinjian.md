所有 10 个无硬件测试已通过，新增的“poll 等待期间跨截止时间”测试确认只写出旧帧第 1 字节，等待推进模拟时钟后立即返回 deadline_timeout，未写剩余 9 字节，
  恢复首帧为零速度 STOP。CMake/CTest 仍因系统未安装而无法运行，我会在最终结果中给出三个命令的实际退出码
## 2. 修改文件

  - CMakeLists.txt
  - README.md
  - include/application.hpp
  - include/exit_status.hpp
  - include/uart_tx_state_machine.hpp
  - src/application.cpp
  - src/config.cpp
  - src/uart_tx_state_machine.cpp
  - tests/test_config.cpp
  - tests/test_exit_status.cpp
  - tests/test_uart_tx.cpp

  ## 3. UART 截止时间修复

  根因是旧接口 process(now, writer) 在进入函数时固定了 now，waitWritable() 返回后仍使用旧时间，可能继续补写已经过期的非零帧。

  现在：

  - 新增 IMonotonicClock 和生产用 SteadyMonotonicClock。
  - UartTxStateMachine 构造时注入时钟。
  - process() 在每次 writeSome() 前重新取时。
  - waitWritable() 返回后再次取时并检查截止时间。
  - 到达或越过截止时间立即返回 deadline_timeout，不再写旧帧。
  - failFrame() 继续负责增加统计、丢弃输出、清空 pending、锁存通信故障和要求恢复 STOP。

  MSPM0 滑动搜索 5A A5、固定10字节、验证 mode/CRC 的重同步要求仍保留在 README。

  ## 4. 等待期间跨截止测试

  test_uart_tx 新增确定性 FakeClock 场景：

  - RATE_CONTROL 帧先写出1字节。
  - 第二次写入返回 EAGAIN。
  - waitWritable() 将模拟时钟推进6 ms，越过5 ms截止时间。
  - 断言事件为 deadline_timeout。
  - 断言 write_calls == 2，没有第三次补写。
  - 断言线路中只有旧帧的1字节。
  - 断言 deadline_timeouts == 1。
  - 恢复后的首个完整帧为零速度 STOP。
  - 断言旧的非零速度没有继续补发。

  原有完整写、1+9部分写、多次EAGAIN、下一周期发现超时和恢复STOP测试均保留。

  ## 5. 配置约束

  validateConfig() 新增：

  uart_poll_timeout_ms / 1000
      必须严格小于 uart_frame_deadline_s
      并且最多占用帧截止时间的一半

  错误信息明确包含“UART poll 等待时间与帧截止时间不匹配”的含义。

  test_config 验证：

  - poll时间等于帧截止时间时拒绝。
  - poll时间大于帧截止时间时拒绝。
  - 错误信息包含 UART poll。
  - 默认配置继续通过验证。

  ## 6. 退出码

  由新增的 ExitReason 和 ExitStatus 决定：

   场景                             退出码
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━
   正常完成                              0
  ───────────────────────────────  ────────
   用户输入 quit                         0
  ───────────────────────────────  ────────
   SIGINT/SIGTERM安全退出                0
  ───────────────────────────────  ────────
   BMI088初始化失败                      2
  ───────────────────────────────  ────────
   UART初始化失败                        2
  ───────────────────────────────  ────────
   真实校准失败或校准SPI连续失败         2
  ───────────────────────────────  ────────
   已锁存的运行故障                      2

  校准期间若用户主动退出或收到信号，stop_requested_ 已设置，不会误记为校准算法失败。

  test_exit_status 验证了全部映射，并确认运行故障锁存后不会被后续SIGTERM覆盖。实际SIGTERM冒烟测试返回0并输出“程序已安全停止”。

  ## 7. 编译和测试结果

  要求的命令已实际执行：

  cmake -S . -B build

  退出码 127：

  cmake: 未找到命令

  cmake --build build -j

  退出码 127：

  cmake: 未找到命令

  ctest --test-dir build --output-on-failure

  退出码 127：

  ctest: 未找到命令

  因此本环境没有产生 CTest 测试数量或通过数量，不能声称 CTest 已通过。

  使用现有编译器执行严格编译：

  g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -pthread ...

  主程序、MSPM0 C协议和全部测试编译退出码均为 0。

  直接运行10个无硬件测试，结果为10/10通过：

  - crc
  - protocol
  - imu_conversion
  - pid
  - mahony
  - uart_tx
  - safety_state
  - config
  - signal
  - exit_status

  ## 8. 编译警告

  严格编译启用了：

  -Wall -Wextra -Wpedantic -Werror

  项目代码没有产生编译警告。

  ## 9. 第一次整改回归检查

  确认仍然成立：

  - 默认 auto_run=false。
  - 校准成功后进入 STOP_READY。
  - 只有人工 run、显式 --auto-run 或 UART测试模式允许 RATE_CONTROL。
  - run 前检查姿态、IMU时效、UART和目标值。
  - STOP、故障和模式切换清空PID状态。
  - UART不建立旧命令队列。
  - UART恢复后首先发送STOP。
  - Mahony门控、积分衰减、积分限幅和拒绝时间统计保留。
  - 信号处理器只设置 sig_atomic_t。
  - README继续要求实机执行 readlink、pinctrl get 14/15。
  - 原始/ 文件未修改。

  ## 10. 仍需实机验证

  - 树莓派5 UART overlay和GPIO14/GPIO15实际设备节点。
  - BMI088芯片ID、轴方向、SPI波形和实际稳定速率。
  - 真实串口在持续EAGAIN、拔线和恢复条件下的行为。
  - 逻辑分析仪验证460800 8N1、10字节、小端和CRC。
  - MSPM0滑动重同步、20～30 ms降速及约100 ms通信故障。
  - 云台低限速运动、STOP、SIGINT、拔SPI/UART、限位、过流和过温保护。