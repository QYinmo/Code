#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace gimbal {

constexpr std::uint16_t kPacketHeader = 0xA55AU;
constexpr std::size_t kPacketLength = 10U;

enum class CommandMode : std::uint8_t {
    stop = 0U,
    rate_control = 1U,
    attitude = 2U,
    fault = 3U
};

struct GimbalCommand {
    std::uint8_t sequence{0U};
    CommandMode mode{CommandMode::stop};
    // rate_control 模式单位为 degree/s；attitude 模式单位为 degree。
    float yaw_rate_dps{0.0F};
    float pitch_rate_dps{0.0F};
};

std::uint16_t crc16Modbus(const std::uint8_t* data, std::size_t length) noexcept;
std::int16_t encodeRate(float rate_dps) noexcept;
std::int16_t encodeAngle(float angle_deg) noexcept;
std::array<std::uint8_t, kPacketLength> serializeCommand(const GimbalCommand& command) noexcept;

} // namespace gimbal
