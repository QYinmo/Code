#include "gimbal_protocol.hpp"

#include <cstdint>
#include <iostream>

int main() {
    const auto packet = gimbal::serializeCommand(
        {0x34U, gimbal::CommandMode::attitude, 12.34F, -5.67F});
    if (packet[0] != 0x5AU || packet[1] != 0xA5U ||
        packet[2] != 0x34U || packet[3] != 0x02U ||
        packet[4] != 0xD2U || packet[5] != 0x04U ||
        packet[6] != 0xC9U || packet[7] != 0xFDU) {
        std::cerr << "姿态模式未按原 10 字节帧的第 5–8 字节编码\n";
        return 1;
    }
    const std::uint16_t crc = static_cast<std::uint16_t>(packet[8]) |
                              (static_cast<std::uint16_t>(packet[9]) << 8U);
    if (crc != gimbal::crc16Modbus(packet.data(), 8U)) {
        std::cerr << "姿态模式 CRC 错误\n";
        return 1;
    }
    if (gimbal::encodeAngle(370.0F) != 1000 ||
        gimbal::encodeAngle(-190.0F) != 17000) {
        std::cerr << "连续 yaw 折回范围错误\n";
        return 1;
    }
    return 0;
}
