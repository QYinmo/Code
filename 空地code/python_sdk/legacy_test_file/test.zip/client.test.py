import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from FlightController import FC_Client
from FlightController.Solutions.Navigation import Navigation

fc = FC_Client()
fc.connect("fc-pc.lan",print_state=True)
