import time

from FlightController.Components.RosManager import RosManager

rm = RosManager()
rm.chmod("/dev/ttyUSB0")
rm.chmod("/dev/video0")
rm.chmod("/dev/video1")
rm.launch_package("ldlidar_stl_ros2", "ld06.launch.py")
rm.launch_package("realsense2_camera", "rs_launch.py")
rm.launch_package("cartographer_ros", "cartographer.launch.py")
rm.run_package("tf2_ros", "static_transform_publisher", "0 0 0 0 0 0 camera_pose_frame base_link")
# rm.run_package("tf2_ros", "tf2_echo", "map camera_pose_frame 10", sub_id=1)
